import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bilet-menu',
  templateUrl: './bilet-menu.component.html',
  styleUrls: ['./bilet-menu.component.css']
})
export class BiletMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
