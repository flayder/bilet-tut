import { Component, OnInit } from '@angular/core';

@Component({
  selector: '[data-app-total-item-buy]',
  templateUrl: './total-item-buy.component.html',
  styleUrls: ['./total-item-buy.component.css']
})
export class TotalItemBuyComponent implements OnInit {
  

  constructor() { }

  ngOnInit(): void {
  }

}
