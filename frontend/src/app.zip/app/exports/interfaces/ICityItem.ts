export interface ICityItem {
    id: number
    name: string
}