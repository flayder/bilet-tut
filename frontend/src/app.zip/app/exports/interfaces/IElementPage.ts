export interface IElementPage {
    id: number
    field: string
    html_field: string
}
