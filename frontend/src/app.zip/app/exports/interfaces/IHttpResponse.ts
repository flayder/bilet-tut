export interface IHttpResponse {
  results: any
  count?: number
  next?: string
  previous?: string
}