export interface IEventCheckerStatus {
    id: number
    code: string
    name: string
}