export interface ICountryItem {
    id: number
    name: string
}