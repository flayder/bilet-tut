export interface IMessage {
  message: string
  type: string
  key?: string
}