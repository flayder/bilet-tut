export interface ICheckoutReturnReason {
    id: number
    name: string
    code: string
}
