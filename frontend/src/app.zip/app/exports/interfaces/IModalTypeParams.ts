import { ModalType } from "../types/ModalType"

export interface IModalTypeParams {
    type: ModalType
    params: any
}