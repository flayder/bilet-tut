export interface IFilterValue {
  name: any
  value: any
  key: any
}