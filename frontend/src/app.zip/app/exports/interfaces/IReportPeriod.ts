export interface IReportPeriod {
    id: number
    name: string
    code: string
    period: number
}
