export interface ICheckoutReturnStatus {
    id: number
    name: string
    code: string
}
