export interface IEventAge {
    id: number
    name: string
    code: string
}
