export interface IPriceAndPlaceReference {
  price_id: number
  place_id: number
}