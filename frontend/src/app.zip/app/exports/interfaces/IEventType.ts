export interface IEventType {
    id: number
    name: string
    code: string
}
