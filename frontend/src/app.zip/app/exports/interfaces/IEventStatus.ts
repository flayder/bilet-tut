export interface IEventStatus {
    id: number
    name: string
    code: string
}
