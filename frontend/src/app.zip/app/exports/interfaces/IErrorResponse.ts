export interface IErrorResponse {
  error?: any
  errors?: any
  status: number
  statusText: string
  results?: any
}
