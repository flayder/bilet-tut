import { IEventAreaSchems } from "./IEventAreaSchems"

export interface IEventAreaPlaces {
    id: number
    name: string
    row: string
    scheme: number[]
}
