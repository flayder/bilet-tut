export interface ISelectValue {
  name: any
  value: any
}