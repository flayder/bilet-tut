export interface IReportType {
    id: number
    name: string
    code: string
}
