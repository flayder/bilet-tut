export interface IEventGenre {
    id: number
    name: string
    code: string
}
