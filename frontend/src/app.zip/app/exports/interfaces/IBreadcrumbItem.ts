export interface IBreadcrumbItem {
    path: string
    name: string
}