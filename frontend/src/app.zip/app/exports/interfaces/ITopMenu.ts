export interface ITopMenu {
  href: string
  name: string
  active?: boolean
}
