export interface ICheckoutStatus {
    id: number
    code: string
    name: string
}