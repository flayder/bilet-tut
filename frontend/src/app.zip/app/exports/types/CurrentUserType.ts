import { IUserItem } from "../interfaces/IUserItem";

export type CurrentUserType = IUserItem | boolean