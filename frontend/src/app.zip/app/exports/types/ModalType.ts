export type ModalType = 
    null | 
    "buy" | 
    "text" |
    "account-price-tiny" |
    "account-category-tiny" |
    "account-promocod-tiny" |
    "account-checker-tiny" |
    "account-iexmport-tiny" |
    "account-mailing-tiny" |
    "account-mailing-item-tiny" |
    "account-user-short" |
    "manager-scheme" |
    "notification-tiny"