export type PaginationType = 
    "events" |
    "banners"