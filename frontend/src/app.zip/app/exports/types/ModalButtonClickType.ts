export type ModalButtonClickType = {
    type: string
}