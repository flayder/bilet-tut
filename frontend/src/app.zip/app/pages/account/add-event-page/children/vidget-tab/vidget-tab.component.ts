import { Component, OnInit } from '@angular/core';

@Component({
  selector: '[data-app-vidget-tab]',
  templateUrl: './vidget-tab.component.html',
  styleUrls: ['./vidget-tab.component.css']
})
export class VidgetTabComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
